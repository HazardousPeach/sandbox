complete --keep-order --exclusive --command sandbox --arguments "(COMPLETE=fish "'sandbox'" -- (commandline --current-process --tokenize --cut-at-cursor) (commandline --current-token))"
